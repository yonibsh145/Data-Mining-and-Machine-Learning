# -*- coding: utf-8 -*-
"""
Created on Mon Dec 14 19:24:05 2020

@author:    Hen Cohen 207063546 
            Yogev Cohen 205744550
            Itay Hugi 301728796
            Yehonatan Ben Shitrit 315687442
"""

from keras.models import Model,Sequential
from keras import layers
from keras.preprocessing.sequence import pad_sequences
from keras.preprocessing.text import one_hot
from keras.utils import np_utils
import matplotlib.pyplot as plt
import numpy as np
import re
from keras.preprocessing.text import Tokenizer
from sklearn.model_selection import train_test_split
import random2
from sklearn.metrics import roc_curve


def load_embedding(filename):
    # load embedding into memory, skip first line
    file = open(filename,'r',encoding='utf8')
    lines = file.readlines()[1:]
    file.close()
    # create a map of words to vectors
    embedding = dict()
    for line in lines:
        parts = line.split()
        # key is string word, value is numpy array for vector
        embedding[parts[0]] = np.array(parts[1:], dtype='float32')
    return embedding

# create a weight matrix for the Embedding layer from a loaded embedding
def get_weight_matrix(embedding, vocab):
    # total vocabulary size plus 0 for unknown words
    vocab_size = len(vocab) + 1
    # define weight matrix dimensions with all 0
    weight_matrix = np.zeros((vocab_size, 100))
    # step vocab, store vectors using the Tokenizer's integer mapping
    for word, i in vocab.items():
        weight_matrix[i] = embedding.get(word)
    
    where_are_NaNs = np.isnan(weight_matrix)
    for j in range(len(where_are_NaNs)):
        for i in range(len(weight_matrix[j])):
            if(random2.randint(1, 2)==1):
                weight_matrix[j,i] = random2.random()*-1
            else:
                weight_matrix[j,i] = random2.random()
            
    return weight_matrix

def clean_str(string):
    """
    Tokenization/string cleaning for all datasets except for SST.
    Every dataset is lower cased except for TREC
    """
    string = re.sub(r"[^A-Za-z0-9(),!?\'\`]", " ", string)
    string = re.sub(r"\'s", " \'s", string)
    string = re.sub(r"\'ve", " \'ve", string)
    string = re.sub(r"n\'t", " n\'t", string)
    string = re.sub(r"\'re", " \'re", string)
    string = re.sub(r"\'d", " \'d", string)
    string = re.sub(r"\'ll", " \'ll", string)
    string = re.sub(r",", " , ", string)
    string = re.sub(r"!", " ! ", string)
    string = re.sub(r"\(", " \( ", string)
    string = re.sub(r"\)", " \) ", string)
    string = re.sub(r"\?", " \? ", string)
    string = re.sub(r"\s{2,}", " ", string)
    return string.strip().lower()

def build_sentences(train_file,test_file):
    """
    Loads datasets of sentances with labels.
    function parse the text and keep track of vocab.
    the text is also cleanned from undesirable simbols of text
    """
    #filename="C:\AI\msr_paraphrase_train.txt"
    f=open(train_file,encoding="utf8")
    print('reading file: '+ train_file + '...')
    f.readline()
    lines=f.readlines()
    labels_train=[]
    sentence_pairs_train=[]
    vocab={}
    max_length=0;
    for line in lines:
        line_split=line.split('\t')
        labels_train.append(line_split[0])
        sentence_pairs_train.append([clean_str(line_split[3]),clean_str(line_split[4])])
    for pair in sentence_pairs_train:
        sentence1=pair[0].split(' ')
        sentence2=pair[1].split(' ')
        max_length=max(max_length,max(len(sentence1),len(sentence2)))
        for word in sentence1:
            vocab[word]=1
        for word in sentence2:
            vocab[word]=1
    f.close()

    f=open(test_file,encoding="utf8")
    print('reading file: '+ test_file + '...')
    f.readline()
    lines=f.readlines()
    labels_test=[]
    sentence_pairs_test=[]
    for line in lines:
        line_split=line.split('\t')
        labels_test.append(line_split[0])
        sentence_pairs_test.append([clean_str(line_split[3]),clean_str(line_split[4])])
    for pair in sentence_pairs_test:
        sentence1=pair[0].split(' ')
        sentence2=pair[1].split(' ')
        max_length=max(max_length,max(len(sentence1),len(sentence2)))
        for word in sentence1:
            vocab[word]=1
        for word in sentence2:
            vocab[word]=1
    f.close()
    return sentence_pairs_train,sentence_pairs_test,labels_train,labels_test,vocab,max_length

#processing the text, in order to receive the sentances pairs and their labels
sentence_pairs_train,sentence_pairs_test,labels_train,labels_test,vocab,max_length = build_sentences("msr_paraphrase_train.txt","msr_paraphrase_test.txt")

#expanding the datasents to have more instances of a subject
sentence_pairs_train = np.concatenate([sentence_pairs_train,sentence_pairs_train],0)
sentence_pairs_test = np.concatenate([sentence_pairs_test,sentence_pairs_test],0)
labels_train = np.concatenate([labels_train,labels_train],0)
labels_test = np.concatenate([labels_test,labels_test],0)

#spliting the data into training and testing
sentence_pairs_train, sentence_pairs_test, labels_train, labels_test = train_test_split(np.concatenate([sentence_pairs_train, sentence_pairs_test],0), np.concatenate([labels_train, labels_test],0), test_size=0.1, random_state=4)

#seperating each sentance from its pair.
print('parsing data...')
X_train_1 = np.array([])
for pair in sentence_pairs_train: 
    X_train_1 = np.append(X_train_1,pair[0])
    
X_test_1 = np.array([])
for pair in sentence_pairs_test: 
    X_test_1 = np.append(X_test_1,pair[0])
    
X_train_2 = np.array([])
for pair in sentence_pairs_train: 
    X_train_2 = np.append(X_train_2,pair[1])
#X_train_2 = np.delete(X_train_2,-1)

X_test_2 = np.array([])
for pair in sentence_pairs_test: 
    X_test_2 = np.append(X_test_2,pair[1])

#fitting the text to the tokenizer
t = Tokenizer()
print('fitting text on tokenizer...')
t.fit_on_texts(np.concatenate([(np.concatenate([X_test_1,X_test_2])),(np.concatenate([X_test_1,X_test_2]))]))
vocab_size = len(t.word_index) + 1

#loading the embedding matrix from the GloVe dataset
print('loading GloVe...')
raw_embedding = load_embedding('glove-wiki-gigaword-100.txt')
embedding_vectors = get_weight_matrix(raw_embedding, t.word_index)
print('GloVe loaded')

#encodding the sentances using the one-hot method (each word recives unique index)
encoded_train_1 = [one_hot(i, vocab_size) for i in X_train_1]
encoded_test_1 = [one_hot(i, vocab_size) for i in X_test_1]
encoded_train_2 = [one_hot(i, vocab_size) for i in X_train_2]
encoded_test_2 = [one_hot(i, vocab_size) for i in X_test_2]

#add padding to the end of each sentance until reaches the max length
X_train_1 = pad_sequences(encoded_train_1, maxlen=max_length, dtype='int32', padding='post')
X_train_2 = pad_sequences(encoded_train_2, maxlen=max_length, dtype='int32', padding='post')
X_test_1 = pad_sequences(encoded_test_1, maxlen=max_length, dtype='int32', padding='post')
X_test_2 = pad_sequences(encoded_test_2, maxlen=max_length, dtype='int32', padding='post')

#convert from string labels to integers
y_train = np.array(labels_train, dtype = 'int32')
y_test = np.array(labels_test, dtype = 'int32')

#categorizing the labels
y_train = np_utils.to_categorical(y_train)
y_test = np_utils.to_categorical(y_test)

#creating the model that handels the first sentance
model_sentence_1 = Sequential()
model_sentence_1.add(layers.Embedding(input_dim=vocab_size,output_dim=100,weights=[embedding_vectors],input_length = max_length,trainable = True))    
model_sentence_1.add(layers.Conv1D(250, 3, activation='relu'))
model_sentence_1.add(layers.MaxPooling1D())
model_sentence_1.add(layers.Conv1D(500, 5, activation='relu'))
model_sentence_1.add(layers.MaxPooling1D())
model_sentence_1.add(layers.Flatten())
model_sentence_1.add(layers.Dense(10, activation='relu'))
model_sentence_1.add(layers.Dropout(.5))

#creating the model that handels the second sentance
model_sentence_2 = Sequential()
model_sentence_2.add(layers.Embedding(input_dim=vocab_size,output_dim=100,weights=[embedding_vectors],input_length = max_length,trainable = True))    
model_sentence_2.add(layers.Conv1D(250, 3, activation='relu'))
model_sentence_2.add(layers.MaxPooling1D())
model_sentence_2.add(layers.Conv1D(500, 5, activation='relu'))
model_sentence_2.add(layers.MaxPooling1D())
model_sentence_2.add(layers.Flatten())
model_sentence_2.add(layers.Dense(10, activation='relu'))
model_sentence_2.add(layers.Dropout(.5))

#merging the two inputs models into the main MLP model
mergedOut = layers.Add()([model_sentence_1.output,model_sentence_2.output])
mergedOut = layers.Dense(15, activation='relu')(mergedOut)
mergedOut = layers.Dropout(.5)(mergedOut)
# output layer
mergedOut = layers.Dense(2, activation='softmax')(mergedOut)

#determine the in/outputs of our model
newModel = Model([model_sentence_1.input,model_sentence_2.input], mergedOut)

# compile the model
newModel.compile(loss='categorical_crossentropy', optimizer='sgd', metrics=['accuracy'])

#start training the model with the data
history=newModel.fit([X_train_1, X_train_2], y_train, validation_data=([X_test_1, X_test_2],y_test), epochs=25, batch_size=25)

#Process ploting
plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('Model accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['Train', 'Test'], loc='upper left')
plt.show()

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model loss')
plt.ylabel('loss')
plt.xlabel('Epoch')
plt.legend(['Train Loss', 'Test Loss'], loc='upper left')
plt.show()

pred = newModel.predict((X_test_1,X_test_2))
pred = pred[:,1]
y_pred = y_test[:,1]
model_fpr, model_tpr, _ = roc_curve(y_pred, pred)

plt.plot(model_fpr,model_tpr,linestyle = '--')
plt.title('ROC Curve')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.show()

# Final evaluation of the model
scores = newModel.evaluate((X_test_1,X_test_2), y_test, verbose=0)
print("CNN Error: %.2f%%" % (100-scores[1]*100))

#test unknown sentence #1
sentance_1 = "The team tried really hard to get a high grade"
sentance_2 = "We learned really well to receive a good grade in ai"
sentance_1 = pad_sequences([one_hot(sentance_1,vocab_size)], maxlen=max_length, dtype='int32', padding='post')
sentance_2 = pad_sequences([one_hot(sentance_2,vocab_size)], maxlen=max_length, dtype='int32', padding='post')

pred = newModel.predict((sentance_1.reshape(1, max_length),sentance_2.reshape(1,max_length)))
print('similar: ' +str(pred[0,1]*100)+' not similar: ' + str(pred[0,0]*100))

#test unknown sentence #2
sentance_1 = "have a good day"
sentance_2 = "have a bad day"
sentance_1 = pad_sequences([one_hot(sentance_1,vocab_size)], maxlen=max_length, dtype='int32', padding='post')
sentance_2 = pad_sequences([one_hot(sentance_2,vocab_size)], maxlen=max_length, dtype='int32', padding='post')

pred = newModel.predict((sentance_1.reshape(1, max_length),sentance_2.reshape(1,max_length)))
print('similar: ' +str(pred[0,1]*100)+' not similar: ' + str(pred[0,0]*100))

#test unknown sentence #3
sentance_1 = "hey how are you mr zeev"
sentance_2 = "lets go for a party"
sentance_1 = pad_sequences([one_hot(sentance_1,vocab_size)], maxlen=max_length, dtype='int32', padding='post')
sentance_2 = pad_sequences([one_hot(sentance_2,vocab_size)], maxlen=max_length, dtype='int32', padding='post')

pred = newModel.predict((sentance_1.reshape(1, max_length),sentance_2.reshape(1,max_length)))
print('similar: ' +str(pred[0,1]*100)+' not similar: ' + str(pred[0,0]*100))