link for GloVe dataset:
https://nlp.stanford.edu/projects/glove/